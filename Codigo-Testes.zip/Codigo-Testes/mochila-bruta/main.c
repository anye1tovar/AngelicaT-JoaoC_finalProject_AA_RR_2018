#include<stdio.h>

// Função utilitária que retorna o máximo entre dois inteiros
int max(int a, int b) { return (a > b)? a : b; }

// Retorna o valor máximo que pode ser posto em uma mochila de tamanho W
int mochila(int W, int wt[], int val[], int n)
{
    // Caso Base
    if (n == 0 || W == 0)
        return 0;
    
    // Se o peso do n-ésimo item da mochila é maior que W, então
    // este item não pode ser incluído na solução ótima
    if (wt[n-1] > W)
        return mochila(W, wt, val, n-1);
    
    // Retorne o máximo de dois casos:
    // (1) n-ésimo item está incluído
    // (2) não está incluído
    else return max( val[n-1] + mochila(W-wt[n-1], wt, val, n-1),
                    mochila(W, wt, val, n-1)
                    );
}

// função de teste
int main()
{
    int val[] = {60, 100, 120};
    int wt[] = {10, 20, 30};
    int W = 50;
    int n = sizeof(val)/sizeof(val[0]);
    printf("Valor máximo: %d\n", mochila(W, wt, val, n));
    return 0;
}

