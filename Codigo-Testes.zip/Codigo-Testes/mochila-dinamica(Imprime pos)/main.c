#include<stdio.h>

// Retorna o valor maximo que pode ser posto em uma mochila de tamanho W
int knapSack(int W, int wt[], int val[], int n)
{
    int i, w;
    int K[n+1][W+1];
    int S[n+1][W+1];
    //int X[n]; //vector binario que indica si el elemento de esa posici�n fue usado o no.
    
    for (i = 0; i <= n; i++)
    {
        for (w = 0; w <= W; w++)
        {
        	 S[i][w] = 0;
        }
    }
    
    // Construir tabela K[][] em bottom up
    for (i = 0; i <= n; i++)
    {
        for (w = 0; w <= W; w++)
        {
            if (i==0 || w==0)
                K[i][w] = 0;
            else if (wt[i-1] <= w)
            	if(val[i-1] + K[i-1][w-wt[i-1]] > K[i-1][w])
				{
            		K[i][w] = val[i-1] + K[i-1][w-wt[i-1]];
            		S[i][w] = i - 1;
				}
				else
				{
					K[i][w] = K[i-1][w];
					S[i][w] = -1; // significa que uso la posisi�n anterios i-1, w para asignar el valor de suma maxima a la matriz
				}
            else
            {
            	K[i][w] = K[i-1][w];
                S[i][w] = -1;
			}                
            printf(" %d", K[i][w]);
        }
        printf("\n");
    }
    printf("\nS: \n");
    for (i = 0; i <= n; i++)
    {
        for (w = 0; w <= W; w++)
        {
        	 printf(" %d", S[i][w]);
        }
        printf("\n");
    }

    int a = n;
    int b = W;
    
    printf("\nAs posicoes dos elementos utilizados foram: ");
    
    while(a >= 1)
	{
		if(S[a][b] != -1){
			
			printf("%d ", S[a][b]);
			a--;
			b = b - wt[a];
		}
		else
		{
			do{
				a--;
			}
			while(S[a][b] == -1);	
		}
	}

	printf("\n");
	
    return K[n][W]; //Devuelve el valor m�ximo que puede haber entre las combinaciones de los eleentos de la mochila cumpliendo la restricci�n de la capacidad maxima
}

// Programa driver
int main()
{        
    int val[] = {3, 1, 2, 3, 1, 2};
    int wt[] = {1, 3, 2, 2, 1, 2};
    int W = 8;
    int n = sizeof(val)/sizeof(val[0]);
    printf("Valor maximo: %d\n", knapSack(W, wt, val, n));
    return 0;
}

